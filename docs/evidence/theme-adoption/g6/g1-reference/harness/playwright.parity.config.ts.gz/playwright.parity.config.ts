import { defineConfig } from '@playwright/test';
import base from './playwright.config';
export default defineConfig({ ...base, use: { ...base.use, baseURL: 'http://127.0.0.1:3110' }, webServer: { command: 'npm run start -- -p 3110', url: 'http://127.0.0.1:3110', reuseExistingServer: false, timeout: 180000 } });
